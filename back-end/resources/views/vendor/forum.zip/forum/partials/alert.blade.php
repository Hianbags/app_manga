<div class="alert alert-{{ $type }} alert-dismissable">
    <button type="button" class="btn-close float-end" data-dismiss="alert" aria-hidden="true"></button>
    <div class="message">
        {!! $message !!}
    </div>
</div>
